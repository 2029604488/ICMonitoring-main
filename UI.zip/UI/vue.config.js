module.exports = {
  publicPath: '',
}
